-- =====================================================================
-- RYUU-STORE — SQL Schema untuk Supabase (Postgres)
-- Jalankan di: Supabase Dashboard > SQL Editor > New Query > Run
-- =====================================================================

-- Ekstensi untuk uuid generator
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------
-- 1. users  (akun user biasa — auth custom username/password, BUKAN Supabase Auth)
-- ---------------------------------------------------------------------
create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  username text not null unique,
  password_hash text not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 2. products
-- ---------------------------------------------------------------------
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(12,2) not null check (price > 0),
  category text,
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 3. orders  (transaksi QRIS)
-- ---------------------------------------------------------------------
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  trx_id text not null unique,                 -- ID transaksi 8 digit acak
  user_id uuid references public.users(id) on delete set null,  -- null = guest
  product_id uuid not null references public.products(id) on delete restrict,
  target text not null,                        -- username/link tujuan suntik sosmed
  amount numeric(12,2) not null,
  status text not null default 'pending'
    check (status in ('pending','success','expired','failed','processing')),
  qris_string text,
  qris_ref text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_orders_trx_id on public.orders(trx_id);
create index if not exists idx_orders_user_id on public.orders(user_id);
create index if not exists idx_orders_status on public.orders(status);

-- ---------------------------------------------------------------------
-- 4. redeem_codes
-- ---------------------------------------------------------------------
create table if not exists public.redeem_codes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  product_id uuid references public.products(id) on delete set null,
  quota integer not null default 1 check (quota > 0),
  used_count integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 5. redeem_history
-- ---------------------------------------------------------------------
create table if not exists public.redeem_history (
  id uuid primary key default gen_random_uuid(),
  redeem_code_id uuid not null references public.redeem_codes(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  redeemed_at timestamptz not null default now(),
  unique (redeem_code_id, user_id)   -- 1 user hanya bisa redeem 1 kode yg sama sekali
);

-- ---------------------------------------------------------------------
-- 6. announcements  (broadcast notifikasi)
-- ---------------------------------------------------------------------
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 7. reviews  (ulasan user)
-- ---------------------------------------------------------------------
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  rating integer not null check (rating between 1 and 5),
  message text not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 8. app_settings  (tambahan di luar 7 tabel wajib — dibutuhkan untuk
--    menyimpan status Mode Maintenance secara persisten)
-- ---------------------------------------------------------------------
create table if not exists public.app_settings (
  key text primary key,
  value text not null
);

insert into public.app_settings (key, value)
values ('maintenance_mode', 'false')
on conflict (key) do nothing;

-- =====================================================================
-- ROW LEVEL SECURITY
-- Semua akses dari aplikasi dilakukan lewat server (service_role key),
-- yang otomatis BYPASS RLS. RLS di sini diaktifkan sebagai lapisan
-- pertahanan agar anon key TIDAK BISA baca/tulis langsung dari browser.
-- =====================================================================
alter table public.users enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.redeem_codes enable row level security;
alter table public.redeem_history enable row level security;
alter table public.announcements enable row level security;
alter table public.reviews enable row level security;
alter table public.app_settings enable row level security;

-- Tidak ada policy yang dibuat untuk role "anon" -> secara default semua
-- akses via anon key DITOLAK. Aplikasi Next.js mengakses data lewat
-- Route Handler (server) memakai service_role key yang bypass RLS.

-- =====================================================================
-- SELESAI
-- =====================================================================
